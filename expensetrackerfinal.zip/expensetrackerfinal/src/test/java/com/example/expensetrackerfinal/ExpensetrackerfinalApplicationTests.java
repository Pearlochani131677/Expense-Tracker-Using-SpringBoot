package com.example.expensetrackerfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpensetrackerfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}

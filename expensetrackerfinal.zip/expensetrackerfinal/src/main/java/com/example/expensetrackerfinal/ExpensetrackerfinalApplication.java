package com.example.expensetrackerfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpensetrackerfinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpensetrackerfinalApplication.class, args);
	}

}
